from django.core.paginator import Paginator, EmptyPage
from django.shortcuts import render

from .models import Questions

# Create your views here.
lst = []
anslist = []
answers = Questions.objects.all()

for i in answers:
    anslist.append(i.answer)


def quiz(request):
    return render(request, "index.html")


def questionpage(request):
    obj = Questions.objects.all()
    paginator = Paginator(obj, 1)
    try:
        page = int(request.GET.get('page', '1'))

    except:

        page = 1
    try:
        questions = paginator.page(page)

    except(EmptyPage, Invalidpage):

        questions = paginator.page(paginator.num_pages)

    return render(request, "question.html", {'obj': obj, 'questions': questions})


def result(request):
    score = 0
    for i in range(len(lst)):
        if lst[i] == anslist[i]:
            score += 1

    return render(request, "result.html", {"score": score})


def saveans(request):
    ans = request.GET['ans']
    list.append(ans)
